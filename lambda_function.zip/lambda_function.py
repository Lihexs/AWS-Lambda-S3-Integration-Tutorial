"""
AWS Lambda function to list all objects in an S3 bucket.

This script is intended for deployment as an AWS Lambda function.
It takes an 'event' input
with a 'BucketName' key to determine the target S3 bucket.
The function lists all objects
in the specified bucket and is equipped to handle a range of common errors.
Additionally, it formats responses in HTTP standard, making it compatible for
interaction with different web services and applications.
"""

import boto3
import json
import logging
import http
from botocore.config import Config
from botocore.exceptions import ClientError, NoCredentialsError

# Constants
MAX_RETRIES = 3
RETRY_MODE = "standard"


# Error messages
ERROR_NO_CREDENTIALS = "No valid credentials provided"
ERROR_NO_BUCKET_NAME = "BucketName not provided in the event"
ERROR_NO_SUCH_BUCKET = "The specified bucket does not exist."
ERROR_ACCESS_DENIED = "Access denied to the specified bucket."
ERROR_INVALID_BUCKET_NAME = "The specified bucket name is not valid."

# Configure logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Configure retries
config = Config(
    retries={
        "max_attempts": MAX_RETRIES,
        "mode": RETRY_MODE,
    }
)

# Initialize s3 client
s3 = boto3.client("s3", config=config)


def lambda_handler(event, context):
    """
    Main handler for the Lambda function.

    Args:
        event (dict): The event dictionary containing
        details about the S3 bucket.
        context (LambdaContext): Provides runtime information
        about the Lambda function.

    Returns:
        dict: A dictionary with the status code and body as the response.

    Raises:
        NoCredentialsError: If no valid AWS credentials are provided.
        ClientError: For errors related to client-side communication with AWS.
    """
    bucket_name = event.get("BucketName")
    if not bucket_name:
        return create_response(http.HTTPStatus.BAD_REQUEST, ERROR_NO_BUCKET_NAME)

    all_objects_name = []
    current_continuation_token = None
    is_truncated = True

    while is_truncated:
        try:
            response = (
                s3.list_objects_v2(
                    Bucket=bucket_name, ContinuationToken=current_continuation_token
                )
                if current_continuation_token
                else s3.list_objects_v2(Bucket=bucket_name)
            )

        except NoCredentialsError:
            return create_response(http.HTTPStatus.UNAUTHORIZED, ERROR_NO_CREDENTIALS)

        except ClientError as e:
            return handle_client_error(e)

        except Exception as e:
            return create_response(
                http.HTTPStatus.INTERNAL_SERVER_ERROR, f"An error occurred: {str(e)}"
            )

        all_objects_name.extend([obj["Key"] for obj in response.get("Contents", [])])
        current_continuation_token = response.get("NextContinuationToken")
        is_truncated = response.get("IsTruncated", False)
    return create_response(http.HTTPStatus.OK, all_objects_name, len(all_objects_name))


def handle_client_error(e):
    """
    Handles client errors encountered when communicating with AWS S3.

    Args:
        e (ClientError): The client error thrown by boto3.

    Returns:
        dict: A response dictionary with appropriate status code and error message.
    """
    error_code = e.response["Error"]["Code"]
    if error_code == "NoSuchBucket":
        return create_response(http.HTTPStatus.NOT_FOUND, ERROR_NO_SUCH_BUCKET)
    elif error_code == "AccessDenied":
        return create_response(http.HTTPStatus.FORBIDDEN, ERROR_ACCESS_DENIED)
    elif error_code == "InvalidBucketName":
        return create_response(http.HTTPStatus.BAD_REQUEST, ERROR_INVALID_BUCKET_NAME)

    # Handle other ClientErrors not specifically caught above
    return create_response(
        http.HTTPStatus.INTERNAL_SERVER_ERROR, f"Unhandled ClientError: {error_code}"
    )


def create_response(status_code, message, object_count=None):
    """
    Creates a formatted HTTP response for the Lambda function.

    This function constructs a response with a given HTTP status code, a message,
    and optionally the count of objects. It is used to standardize the response
    structure for both successful and error scenarios.

    Args:
        status_code (int): HTTP status code for the response.
        message (str): Detail message for the response.
        object_count (int, optional): Count of objects to be included
        in the response, if applicable.

    Returns:
        dict: A dictionary with 'statusCode' and 'body', where 'body'
        is a JSON-formatted string.
    """
    if status_code != http.HTTPStatus.OK:
        logger.error(f"Error response: {message}")
        response_body = {"message": message}
    else:
        response_body = (
            {
                "totalObjects": object_count,
                "message": message,
            }
            if object_count is not None
            else {"message": message}
        )

    return {"statusCode": status_code, "body": json.dumps(response_body)}
